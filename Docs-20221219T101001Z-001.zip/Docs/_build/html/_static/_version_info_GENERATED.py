version_info = (
{
  "build_mtime": "1663951639",
  "module_name": "sphinx_typo3_theme",
  "version_scm": "4.7.9",
  "version_scm_build": "",
  "version_scm_core": "4.7.9",
  "version_scm_pre_release": ""
}
)
