object\_detection module
========================
The object_detection() module consists of two functions; one is used to load our YOLO model and the other is used to actually use the model to predict/detect objects in an image.

.. automodule:: object_detection
   :members:
   :undoc-members:
   :show-inheritance:
