image\_utils module
===================
This image_utils() module is one of the main components related to image processing in our application. This module has various utilities like rescaling ROI, to annotate an image, to check whether an object is intersecting with the selected area or not, etc.

.. automodule:: image_utils
   :members:
   :undoc-members:
   :show-inheritance:
