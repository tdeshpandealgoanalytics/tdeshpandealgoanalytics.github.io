object\_area module
===================

.. automodule:: object_area
   :members:
   :undoc-members:
   :show-inheritance:
