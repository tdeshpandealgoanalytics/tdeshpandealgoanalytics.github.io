image\_popup module
===================
The image_popup() module contains the UI functionality to display an image popup at different instances across our application.

.. automodule:: image_popup
   :members:
   :undoc-members:
   :show-inheritance:
