main\_rule\_based module
========================

.. automodule:: main_rule_based
   :members:
   :undoc-members:
   :show-inheritance:
