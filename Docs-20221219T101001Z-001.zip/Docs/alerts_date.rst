alerts\_date module
===================
The alerts_date module acts as a supporting function to the app_new() script; in which this module provides a well constructed frame of alerts as well as their corresponding date, hour and minutes.

.. automodule:: alerts_date
   :members:
   :undoc-members:
   :show-inheritance:
