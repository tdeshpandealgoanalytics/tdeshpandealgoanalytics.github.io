deletion module
===============
The deletion() module is a short function used to delete a directory tree from the local system where Aksha is installed.

.. automodule:: deletion
   :members:
   :undoc-members:
   :show-inheritance:
