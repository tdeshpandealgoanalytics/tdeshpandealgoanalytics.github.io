encrypt module
==============
This encrypt() module is used for various encryption purposes. It includes functions used to encrypt and decrypt passwords as well as to generate and load a key.

.. automodule:: encrypt
   :members:
   :undoc-members:
   :show-inheritance:
