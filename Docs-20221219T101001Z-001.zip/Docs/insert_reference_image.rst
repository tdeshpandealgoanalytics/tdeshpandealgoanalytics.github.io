insert\_reference\_image module
===============================

.. automodule:: insert_reference_image
   :members:
   :undoc-members:
   :show-inheritance:
