purging module
==============
As the name suggests, the purging() module is specifically aimed for the process of deletion/purging an entire directory from the local system.

.. automodule:: purging
   :members:
   :undoc-members:
   :show-inheritance:
