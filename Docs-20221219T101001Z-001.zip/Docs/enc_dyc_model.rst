enc\_dyc\_model module
======================
The eny_dyc_cfg() module is a short abbreviation for an encrypt decrypt module. This particular module is responsible for the encryption and decryption of the YOLO model's weights(.weights) file.


.. automodule:: enc_dyc_model
   :members:
   :undoc-members:
   :show-inheritance:
