utilities module
================
This utilities() module is a short module consisting of only two functions but execute a crucial job across the application.

.. automodule:: utilities
   :members:
   :undoc-members:
   :show-inheritance:
