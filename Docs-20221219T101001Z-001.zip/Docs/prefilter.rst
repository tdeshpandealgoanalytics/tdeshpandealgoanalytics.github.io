prefilter module
================

.. automodule:: prefilter
   :members:
   :undoc-members:
   :show-inheritance:
