src
===

.. toctree::
   :maxdepth: 4

   alerts_date
   anomaly_check
   app
   app_new
   camera_database
   config
   data_collection
   database_config
   deletion
   email_handler
   enc_dyc_cfg
   enc_dyc_model
   encrypt
   forms
   image_popup
   image_utils
   insert_image_reference
   main_rule_based
   main_rule_based_time
   main_with_object_based_anomaly
   mongo
   object_area
   object_detection
   object_multi_area_point
   prefilter
   process_creator
   purging
   rule_popup
   utilities
