process\_creator module
=======================
This process_creator() module basically has function to check if process is running and return status. If the process is shut down; it respawns the process.

.. automodule:: process_creator
   :members:
   :undoc-members:
   :show-inheritance:
