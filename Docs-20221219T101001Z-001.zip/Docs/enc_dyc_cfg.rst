enc\_dyc\_cfg module
====================
The eny_dyc_cfg() module is a short abbreviation for an encrypt decrypt module. This particular module is responsible for the encryption and decryption of the YOLO model's configuration(.cfg) file.

.. automodule:: enc_dyc_cfg
   :members:
   :undoc-members:
   :show-inheritance:
