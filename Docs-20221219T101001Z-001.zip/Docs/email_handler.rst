email\_handler module
=====================
The email_handler() module; as the name suggests handles the process of intimidating or informing a user through email communication. This module contains various functions specified for various use cases like sending emails with one attachments or multiple attachments, sending email about the status of camera, sending an email if anomaly is detected, etc.

.. automodule:: email_handler
   :members:
   :undoc-members:
   :show-inheritance:
