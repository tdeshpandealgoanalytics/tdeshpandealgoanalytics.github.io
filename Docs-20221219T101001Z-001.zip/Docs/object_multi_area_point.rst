object\_multi\_area\_point module
=================================
The object_multi_point_area() module is one of the most important modules in our application. This module consists of various functions that gives user the ability to draw and manipulate a specific region of their own choice onto a frame of any camera.

.. automodule:: object_multi_area_point
   :members:
   :undoc-members:
   :show-inheritance:

Any user may be able to select a specific area as shown in the image below:

.. image:: image.jpg
   :height: 300px
   :width: 300px
   :align: center