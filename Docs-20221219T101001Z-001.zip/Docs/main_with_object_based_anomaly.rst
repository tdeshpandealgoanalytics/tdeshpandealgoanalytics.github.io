main\_with\_object\_based\_anomaly module
=========================================

.. automodule:: main_with_object_based_anomaly
   :members:
   :undoc-members:
   :show-inheritance:
