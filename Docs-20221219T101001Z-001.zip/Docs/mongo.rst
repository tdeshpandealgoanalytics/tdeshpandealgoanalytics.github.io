mongo module
============
This mongo() module contains necessary and supporting function used to manipulate data from and into our mongoDB database. It has provisions to add new data, delete past data, as well as to update the information in a .csv file.

.. automodule:: mongo
   :members:
   :undoc-members:
   :show-inheritance:
