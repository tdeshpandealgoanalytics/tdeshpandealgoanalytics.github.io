app\_new module
===============

The app_new() module is one of the most important scripts created for our use case.

This module is solely responsible for the displaying the frontend/UI part of Aksha. The app_new() module takes help of a number of different scripts/functions in order to carry out different tasks.

.. automodule:: app_new
   :members:
   :undoc-members:
   :show-inheritance:
