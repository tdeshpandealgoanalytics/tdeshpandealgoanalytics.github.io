rule\_popup module
==================
The rule_popup() module consists of functions that help to view the information regarding any alert in a popup window on the UI/frontend.

.. automodule:: rule_popup
   :members:
   :undoc-members:
   :show-inheritance:
