forms module
============
This forms() moduleplays one of the crucial roles in Aksha. This module contains all the functions related to Cameras on our UI. This module has the functionalities to add a new camera, to update an existing camera's configuration or to view configurations of an existing camera.

.. automodule:: forms
   :members:
   :undoc-members:
   :show-inheritance:
