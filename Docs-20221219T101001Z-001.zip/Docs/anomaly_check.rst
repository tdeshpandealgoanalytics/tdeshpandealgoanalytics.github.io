anomaly\_check module
=====================
The anomaly_check() module is a small supporting function used in main_rule_based_time() function in order to check whether for a specific camera the anomaly alerts are allowed to be displayed or not.

.. automodule:: anomaly_check
   :members:
   :undoc-members:
   :show-inheritance:
