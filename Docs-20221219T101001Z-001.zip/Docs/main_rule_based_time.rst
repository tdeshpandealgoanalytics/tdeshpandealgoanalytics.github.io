main\_rule\_based\_time module
==============================
This main_rule_based_time() module is the most crucial module regarding the backend functionality of our Application.
This module is solely responsible for the backend/machine learning part of Aksha. The main_rule_based_time() module takes help of a number of different scripts/functions in order to carry out different tasks.


.. automodule:: main_rule_based_time
   :members:
   :undoc-members:
   :show-inheritance:
