camera\_database module
=======================

The camera_database() module consists of all the necessary and important functions related to camera's configuration.

This module provides a range of functionality; all related to cameras in our system like adding an additional camera to our database, editing the config to any specific camera, load or update configuration or a single camera or all cameras, add rules to the specific camera or all the cameras and also to delete any specifc rule for a single or all the cameras.

.. automodule:: camera_database
   :members:
   :undoc-members:
   :show-inheritance:
