database\_config module
=======================
The database_config() module contains not extensive but crucial information. It contains connection url for mongoDB as well as the database name.

.. automodule:: database_config
   :members:
   :undoc-members:
   :show-inheritance:
